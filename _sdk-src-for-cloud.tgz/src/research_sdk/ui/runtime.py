"""Runtime adapter connecting scenarios to grSim and the planner API."""

from __future__ import annotations

import inspect
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from math import cos, hypot, sin
from pathlib import Path
from time import perf_counter

import yaml

from research_sdk.config import ROBOT_RADIUS_MM, planning_clearance_mm
from research_sdk.network.command_dispatcher import RobotCommandDispatcher
from research_sdk.network.grSimPacketFactory import grSimPacketFactory
from research_sdk.network.robot_command import RobotCommand
from research_sdk.network.ssl_sockets import grSimSender
from research_sdk.planners import PlannerAPI, PlannerInput, VoronoiDijkstraPlanner
from research_sdk.ui.scenarios import DEFAULT_PATROL_SPEED_MMPS, Scenario
from research_sdk.world.pipeline import VisionWorldPipeline, WorldPipelineUpdate
from research_sdk.world.scene import PlanningObstacle, PlanningScene
from research_sdk.world.snapshot import WorldSnapshot


@dataclass(frozen=True, slots=True)
class PlannedRobotPath:
    robot_id: int
    is_yellow: bool
    points_mm: tuple[tuple[float, float], ...]
    failed: bool = False


@dataclass(frozen=True, slots=True)
class ConnectionProbe:
    destination: tuple[str, int]
    local_address: tuple[str, int]


@dataclass(frozen=True, slots=True)
class LiveRobot:
    robot_id: int
    is_yellow: bool
    position_mm: tuple[float, float]
    orientation_rad: float


@dataclass(frozen=True, slots=True)
class LiveWorldFrame:
    robots: tuple[LiveRobot, ...]
    ball_mm: tuple[float, float] | None


def live_world_from_vision_packet(packet) -> LiveWorldFrame | None:
    """Convert one SSL-Vision wrapper detection into canvas-friendly values."""
    if packet is None or not packet.HasField("detection"):
        return None
    detection = packet.detection
    robots = tuple(
        LiveRobot(
            robot_id=int(robot.robot_id),
            is_yellow=is_yellow,
            position_mm=(float(robot.x), float(robot.y)),
            orientation_rad=float(robot.orientation),
        )
        for is_yellow, team in (
            (True, detection.robots_yellow),
            (False, detection.robots_blue),
        )
        for robot in team
    )
    ball = max(detection.balls, key=lambda item: item.confidence, default=None)
    ball_mm = None if ball is None else (float(ball.x), float(ball.y))
    return LiveWorldFrame(robots=robots, ball_mm=ball_mm)


def live_world_from_snapshot(snapshot: WorldSnapshot) -> LiveWorldFrame:
    robots = (*snapshot.yellow, *snapshot.blue)
    return LiveWorldFrame(
        robots=tuple(
            LiveRobot(robot.robot_id, robot.isYellow, robot.position, robot.theta)
            for robot in robots
            if robot is not None
        ),
        ball_mm=None if snapshot.ball is None else snapshot.ball.position,
    )


def waypoint_command(
    robot: LiveRobot,
    target_mm: tuple[float, float],
    *,
    gain_per_second: float = 2.0,
    max_speed_mps: float | None = None,
) -> RobotCommand:
    """Create a grSim robot-local velocity command toward a world-frame point."""
    error_x_m = (target_mm[0] - robot.position_mm[0]) / 1000.0
    error_y_m = (target_mm[1] - robot.position_mm[1]) / 1000.0
    world_vx = gain_per_second * error_x_m
    world_vy = gain_per_second * error_y_m
    speed = hypot(world_vx, world_vy)
    if max_speed_mps is not None and speed > max_speed_mps > 0:
        world_vx *= max_speed_mps / speed
        world_vy *= max_speed_mps / speed
    heading = robot.orientation_rad
    local_vx = cos(heading) * world_vx + sin(heading) * world_vy
    local_vy = -sin(heading) * world_vx + cos(heading) * world_vy
    return RobotCommand(
        robot_id=robot.robot_id,
        isYellow=robot.is_yellow,
        vx=local_vx,
        vy=local_vy,
    )


def _accepts_use_reroute_gate(planner_cls: type) -> bool:
    """Whether ``planner_cls(...)`` understands ``use_reroute_gate``.

    ``set_planner`` stays generic over anything ``discover_planners()`` finds
    (or a test double like ``_CapturingPlanner`` with a bare no-arg
    constructor) -- only planners that actually declare the kwarg (or accept
    ``**kwargs``) get it, everything else is constructed exactly as before.
    """
    try:
        parameters = inspect.signature(planner_cls).parameters
    except (TypeError, ValueError):
        return False
    return "use_reroute_gate" in parameters or any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values()
    )


def planner_key(planner_cls: type | None) -> str | None:
    """Return the persistent identifier used by scenario obstacle layouts."""
    if planner_cls is None:
        return None
    return f"{planner_cls.__module__}.{planner_cls.__qualname__}"


class ResearchRuntime:
    def __init__(
        self,
        *,
        parallel_planning: bool = True,
        predict_motion: bool = False,
        use_reroute_gate: bool = True,
        scene_recompute_interval_s: float = 0.02,
        command_send_hz: float = 100.0,
        command_ttl_s: float = 0.2,
    ) -> None:
        self._sender: grSimSender | None = None
        self._network_config_mtime: float | None = None
        self._network_config_destination: tuple[str, int] | None = None
        self._command_dispatcher = RobotCommandDispatcher(
            lambda command: self._get_sender().send_robot_command(command),
            send_hz=command_send_hz,
            command_ttl_s=command_ttl_s,
        )
        self._planner = PlannerAPI()
        self._planner_key: str | None = None
        self._recorder = None
        self.last_send_latency_ms: float | None = None
        self.last_receive_latency_ms: float | None = None
        self.last_pipeline_update: WorldPipelineUpdate | None = None
        self.last_plan_durations_ms: tuple[float, ...] = ()
        self.last_plan_failures = 0
        # Policy switch, not a perf-critical default: each robot's plan() call
        # is independent (obstacles are a snapshot of the scene, not built from
        # other robots' *new* paths), so planning them on a thread pool instead
        # of one at a time is safe. See docs/decisions/0005-parallel-planner-
        # execution.md for the benchmark data behind this and why a thread pool
        # (not a process pool) is the default -- flip to False to restore the
        # old strictly-sequential behaviour for debugging/comparison.
        self.parallel_planning = parallel_planning
        # Policy switch, off by default (changes *what* gets planned against,
        # not just how fast): when True, a robot's teammates/opponents are
        # sourced from self.world_pipeline.latest_scene (real tracked
        # position + velocity-projected position and motion-inflated radius,
        # built by WorldMap.planning_scene() -- see
        # world/map/world_map.py:370) instead of their static scenario
        # start_mm. This is planner-agnostic: it swaps the obstacle *source*
        # before any planner sees it, so VisibilityGraph/PRM/Voronoi all get
        # the same upgrade with no per-planner code. Falls back to the static
        # behaviour automatically whenever no live scene exists yet (e.g.
        # vision hasn't produced a frame since reset), so turning it on is
        # never destructive. See docs/decisions/0005-parallel-planner-
        # execution.md, "Future work".
        self.predict_motion = predict_motion
        # Policy switch for A/B comparison: True (default) gates a planner's
        # full reroute behind a cheap is_path_free check on its own active
        # waypoint segment (see planners/reroute.py); False reproduces every
        # planner's pre-extraction behaviour of always rerouting from scratch
        # whenever the direct line to the target isn't clear.
        self.use_reroute_gate = use_reroute_gate
        self.planning_clearance_mm = planning_clearance_mm()
        # Same cheap-check-first philosophy as the reroute gate above, applied
        # to the vision pipeline: rebuilding the planning scene (per-obstacle
        # predicted-position/dynamic-radius math) on every single vision frame
        # is wasted work between frames close enough together that nothing
        # meaningful changed. Only actually rebuild it once this much time has
        # passed; reuse the last one otherwise. The UI also renders this scene,
        # so it must keep refreshing even while motion prediction is disabled;
        # in that mode it is rebuilt with a zero prediction horizon.
        self.scene_recompute_interval_s = scene_recompute_interval_s
        self._last_scene_recompute_at: float | None = None
        self._last_scene_predict_motion: bool | None = None
        self.world_pipeline = VisionWorldPipeline(cameras=4)
        self.active_paths: tuple[PlannedRobotPath, ...] = ()
        self._active_paths: dict[tuple[bool, int], PlannedRobotPath] = {}
        self._waypoint_indices: dict[tuple[bool, int], int] = {}
        self._patrol_paths: dict[tuple[bool, int], tuple[tuple[float, float], ...]] = {}
        self._patrol_indices: dict[tuple[bool, int], int] = {}
        self._patrol_directions: dict[tuple[bool, int], int] = {}
        self._patrol_speeds: dict[tuple[bool, int], float] = {}
        self._paused = False
        self._step_mode = False
        self._step_boundary_indices: dict[tuple[bool, int], int] = {}
        self.step_completed = False
        self.last_waypoint_transitions: tuple[
            tuple[tuple[bool, int], int], ...
        ] = ()

    def ingest_vision_packet(self, packet) -> LiveWorldFrame | None:
        """Update the runtime's world-state boundary from one vision packet.

        The planning scene's prediction horizon tracks ``predict_motion``
        directly: no horizon at all when motion prediction is off (a live
        scene isn't even consulted for planning in that case -- see
        ``_other_robot_obstacles`` -- so predicting into the future here
        would be wasted work), and a short 50ms look-ahead when it's on.

        The scene itself is only actually rebuilt at most once per
        ``scene_recompute_interval_s`` (20ms baseline -- vision frames arrive
        far faster than that). This applies in both modes because the UI
        renders the latest scene even when planning does not consume it.
        Every other call reuses ``world_pipeline.latest_scene`` untouched.
        """
        now = perf_counter()
        compute_scene = (
            self._last_scene_recompute_at is None
            or self._last_scene_predict_motion is not self.predict_motion
            or now - self._last_scene_recompute_at >= self.scene_recompute_interval_s
        )
        horizon_ms = 50.0 if self.predict_motion else 0.0
        update = self.world_pipeline.ingest(
            packet, horizon_ms=horizon_ms, compute_scene=compute_scene
        )
        if compute_scene and update is not None:
            self._last_scene_recompute_at = now
            self._last_scene_predict_motion = self.predict_motion
        self.last_pipeline_update = update
        return None if update is None else live_world_from_snapshot(update.snapshot)

    @property
    def world_snapshot(self) -> WorldSnapshot | None:
        return self.world_pipeline.store.current

    @property
    def live_robots(self) -> dict[tuple[bool, int], LiveRobot]:
        snapshot = self.world_snapshot
        if snapshot is None:
            return {}
        return {
            (robot.isYellow, robot.robot_id): LiveRobot(
                robot.robot_id,
                robot.isYellow,
                robot.position,
                robot.theta,
            )
            for robot in (*snapshot.yellow, *snapshot.blue)
            if robot is not None
        }

    def apply_scenario(self, scenario: Scenario, *, include_obstacles: bool = True) -> None:
        replacements = [
            {
                "x": robot.start_mm[0] / 1000.0,
                "y": robot.start_mm[1] / 1000.0,
                "orientation": robot.orientation_rad,
                "robot_id": robot.robot_id,
                "isYellow": robot.is_yellow,
            }
            for robot in scenario.robots
        ]
        if include_obstacles:
            replacements.extend(
                {
                    "x": obstacle.position_mm[0] / 1000.0,
                    "y": obstacle.position_mm[1] / 1000.0,
                    "orientation": 0.0,
                    "robot_id": obstacle.obstacle_id,
                    "isYellow": obstacle.is_yellow,
                }
                for obstacle in scenario.obstacles_for(self._planner_key)
            )
        packet = grSimPacketFactory.scenario_replacement_command(replacements)
        started = perf_counter()
        self._get_sender().send_packet(packet)
        if scenario.ball is not None:
            ball_packet = grSimPacketFactory.ball_replacement_command(
                x=scenario.ball.position_mm[0] / 1000.0,
                y=scenario.ball.position_mm[1] / 1000.0,
                vx=scenario.ball.velocity_mmps[0] / 1000.0,
                vy=scenario.ball.velocity_mmps[1] / 1000.0,
            )
            self._get_sender().send_packet(ball_packet)
        self.last_send_latency_ms = (perf_counter() - started) * 1000.0

    def _obstacles_for_robot(
        self, scenario: Scenario, robot
    ) -> tuple[PlanningObstacle, ...]:
        scenario_obstacles = tuple(
            PlanningObstacle(
                robot_id=obstacle.obstacle_id,
                isYellow=obstacle.is_yellow,
                pos_mm=obstacle.position_mm,
                radius_mm=obstacle.radius_mm,
                vel_mmps=obstacle.velocity_mmps,
            )
            for obstacle in scenario.obstacles_for(self._planner_key)
        )
        return scenario_obstacles + self._other_robot_obstacles(scenario, robot)

    def _other_robot_obstacles(
        self, scenario: Scenario, robot
    ) -> tuple[PlanningObstacle, ...]:
        live_scene = self.world_pipeline.latest_scene if self.predict_motion else None
        if live_scene is not None:
            robot_key = (robot.is_yellow, robot.robot_id)
            return tuple(
                obstacle for obstacle in live_scene.obstacles if obstacle.key != robot_key
            )
        # No live tracked scene (predict_motion is off, or vision hasn't
        # produced a frame yet) -- fall back to each teammate/opponent's
        # static scenario position, exactly as before this toggle existed.
        return tuple(
            PlanningObstacle(
                robot_id=other.robot_id,
                isYellow=other.is_yellow,
                pos_mm=other.start_mm,
                radius_mm=ROBOT_RADIUS_MM,
            )
            for other in scenario.robots
            if other != robot
        )

    def _plan_one_robot(self, scenario: Scenario, robot) -> tuple[PlannedRobotPath, float]:
        """Plan one robot's path and time it.

        On failure, re-raises whatever ``self._planner.plan()`` raised, with
        the elapsed time up to the failure attached as ``.duration_ms`` --
        callers use that to keep timing full even for a failed attempt,
        matching the original serial implementation's ``finally``-based
        timing.

        Only touches ``self._planner`` (read) and locals -- safe to call from
        multiple threads at once, one call per robot, since ``scenario`` is a
        snapshot and each robot's obstacle set is independent of every other
        robot's *planned* path (only their current ``start_mm``, already
        fixed before planning starts).
        """
        assert robot.target_mm is not None
        obstacles = self._obstacles_for_robot(scenario, robot)
        scene = PlanningScene(timestamp=perf_counter(), obstacles=obstacles)
        started = perf_counter()
        try:
            result = self._planner.plan(
                PlannerInput(
                    robot_id=robot.robot_id,
                    is_yellow=robot.is_yellow,
                    current_pose=(*robot.start_mm, robot.orientation_rad),
                    target_pose=(*robot.target_mm, robot.orientation_rad),
                    scene=scene,
                    clearance_mm=self.planning_clearance_mm,
                    record=self._recorder,
                )
            )
        except Exception as exc:
            exc.duration_ms = (perf_counter() - started) * 1000.0
            raise
        duration_ms = (perf_counter() - started) * 1000.0
        points = [robot.start_mm, *[(p[0], p[1]) for p in result.waypoints]]
        if points[-1] != robot.target_mm:
            points.append(robot.target_mm)
        path = PlannedRobotPath(robot.robot_id, robot.is_yellow, tuple(points))
        return path, duration_ms

    def _run_and_track(self, robot, call, durations_ms: list[float]) -> PlannedRobotPath:
        """Run one already-scheduled plan attempt for ``robot``, track its
        duration and failure count -- shared by both the serial and
        thread-pool branches of ``plan()`` so they stay behaviourally
        identical.

        On failure, this does *not* raise or abort the rest of the batch:
        it returns a stationary (``points_mm`` is just the robot's current
        position), ``failed=True`` path instead. One robot's planner
        failure (no route found, etc.) shouldn't stop every other robot
        from getting a path -- the UI flags a ``failed`` robot red and
        leaves it in place (see ``app.py``'s ``_draw_robot``/
        ``_draw_planned_robot``) rather than the whole plan-all-robots call
        raising.
        """
        try:
            path, duration_ms = call()
        except Exception as exc:
            self.last_plan_failures += 1
            durations_ms.append(getattr(exc, "duration_ms", 0.0))
            self.last_plan_durations_ms = tuple(durations_ms)
            return PlannedRobotPath(robot.robot_id, robot.is_yellow, (robot.start_mm,), failed=True)
        durations_ms.append(duration_ms)
        return path

    def plan(self, scenario: Scenario) -> tuple[PlannedRobotPath, ...]:
        scenario.require_complete()
        self.last_plan_durations_ms = ()
        self.last_plan_failures = 0
        robots = list(scenario.robots)
        durations_ms: list[float] = []
        paths: list[PlannedRobotPath] = []

        if self.parallel_planning and len(robots) > 1:
            with ThreadPoolExecutor(max_workers=len(robots)) as executor:
                futures = [executor.submit(self._plan_one_robot, scenario, robot) for robot in robots]
                for robot, future in zip(robots, futures):
                    paths.append(self._run_and_track(robot, future.result, durations_ms))
        else:
            for robot in robots:
                call = lambda robot=robot: self._plan_one_robot(scenario, robot)
                paths.append(self._run_and_track(robot, call, durations_ms))

        self.last_plan_durations_ms = tuple(durations_ms)
        return tuple(paths)

    def replan_active_robots(
        self,
        scenario: Scenario,
        live_robots: dict[tuple[bool, int], LiveRobot],
    ) -> dict[tuple[bool, int], PlannedRobotPath]:
        """Re-evaluate the active (owning) planner's route for every robot
        currently executing, from its *live* position rather than its
        scenario ``start_mm``.

        Calling this every vision frame is what makes the reroute gate in
        ``planners/reroute.py`` actually reactive: most calls are cheap (the
        gate's own ``is_path_free`` check on the active segment) and return
        ``did_reroute=False``, so only robots whose route genuinely needs to
        change end up in the returned mapping. One robot's replan failure
        (planner exception) is logged-and-skipped here rather than raised,
        matching ``_run_and_track``'s per-robot isolation -- a transient
        failure on one robot must not stop this from being called again next
        frame, or block every other robot's replan this frame.
        """
        changed: dict[tuple[bool, int], PlannedRobotPath] = {}
        for robot in scenario.robots:
            key = (robot.is_yellow, robot.robot_id)
            if key not in self._active_paths:
                continue
            live = live_robots.get(key)
            if live is None or robot.target_mm is None:
                continue
            obstacles = self._obstacles_for_robot(scenario, robot)
            scene = PlanningScene(timestamp=perf_counter(), obstacles=obstacles)
            try:
                result = self._planner.plan(
                    PlannerInput(
                        robot_id=robot.robot_id,
                        is_yellow=robot.is_yellow,
                        current_pose=(*live.position_mm, live.orientation_rad),
                        target_pose=(*robot.target_mm, robot.orientation_rad),
                        scene=scene,
                        clearance_mm=self.planning_clearance_mm,
                        record=self._recorder,
                    )
                )
            except Exception:  # noqa: BLE001, S112 - one robot's replan failure must not skip the rest
                continue
            if not result.did_reroute:
                continue
            points = [live.position_mm, *[(p[0], p[1]) for p in result.waypoints]]
            if points[-1] != robot.target_mm:
                points.append(robot.target_mm)
            new_path = PlannedRobotPath(robot.robot_id, robot.is_yellow, tuple(points))
            self._active_paths[key] = new_path
            self._waypoint_indices[key] = min(1, len(new_path.points_mm))
            changed[key] = new_path
        if changed:
            self.active_paths = tuple(self._active_paths.values())
        return changed

    def set_planner(self, planner_cls: type | None, *, record=None) -> None:
        """Swap the active planner, e.g. from the UI's "Active planner" dropdown.

        ``VoronoiDijkstraPlanner`` is discoverable but implements a different,
        lower-level ``.plan(scene, start, target, ...)`` signature (it is
        VoronoiWaypointManager's internal building block, not itself a
        PlannerAPI-shaped planner) -- selecting it maps back onto the default
        ``PlannerAPI()`` rather than instantiating it directly. ``record`` is
        stashed on ``self._recorder`` for this branch and attached to every
        ``PlannerInput`` built in ``_plan_one_robot`` instead, since
        ``PlannerAPI``/``VoronoiWaypointManager`` construct a fresh
        ``VoronoiDijkstraPlanner`` per call rather than taking one at
        construction time the way ``VisibilityGraphPlanner``/``PRMPlanner`` do.
        """
        self._planner_key = planner_key(planner_cls)
        # Clearance follows the selected planner's config entry (the shared
        # value unless planner_variables.yaml overrides it for that planner).
        self.planning_clearance_mm = planning_clearance_mm(
            None if planner_cls is None else planner_cls.__name__
        )
        if planner_cls is None or planner_cls is VoronoiDijkstraPlanner:
            self._planner = PlannerAPI(use_reroute_gate=self.use_reroute_gate)
            self._recorder = record
        else:
            kwargs = {}
            if record is not None:
                kwargs["record"] = record
            if _accepts_use_reroute_gate(planner_cls):
                kwargs["use_reroute_gate"] = self.use_reroute_gate
            self._planner = planner_cls(**kwargs)
            self._recorder = None

    def reset_planner(self) -> None:
        self._planner.reset()

    def start_execution(
        self,
        paths: tuple[PlannedRobotPath, ...],
        *,
        waypoint_indices: dict[tuple[bool, int], int] | None = None,
        paused: bool = False,
        scenario: Scenario | None = None,
    ) -> None:
        self.active_paths = paths
        self._active_paths = {(path.is_yellow, path.robot_id): path for path in paths}
        defaults = {
            key: min(1, len(path.points_mm)) for key, path in self._active_paths.items()
        }
        self._waypoint_indices = defaults
        if waypoint_indices is not None:
            for key, index in waypoint_indices.items():
                if key in self._active_paths:
                    self._waypoint_indices[key] = max(
                        0, min(int(index), len(self._active_paths[key].points_mm))
                    )
        # Same route the canvases draw and the headless runner uses: spawn
        # point, then each waypoint, retraced back and forth.
        self._patrol_paths = {
            (obstacle.is_yellow, obstacle.obstacle_id): (
                tuple(obstacle.position_mm),
                *obstacle.patrol_waypoints,
            )
            for obstacle in (scenario.obstacles if scenario is not None else ())
            if obstacle.patrol_waypoints
        }
        self._patrol_speeds = {
            (obstacle.is_yellow, obstacle.obstacle_id): (
                obstacle.patrol_speed_mmps or DEFAULT_PATROL_SPEED_MMPS
            )
            / 1000.0
            for obstacle in (scenario.obstacles if scenario is not None else ())
            if obstacle.patrol_waypoints
        }
        self._patrol_indices = {key: 0 for key in self._patrol_paths}
        self._patrol_directions = {key: 1 for key in self._patrol_paths}
        self._paused = bool(paused)
        self._step_mode = False
        self._step_boundary_indices.clear()
        self.step_completed = False
        self.last_waypoint_transitions = ()
        self._command_dispatcher.start()
        if paused:
            self._send_zero_to_active()

    @property
    def waypoint_indices(self) -> dict[tuple[bool, int], int]:
        return dict(self._waypoint_indices)

    @property
    def paused(self) -> bool:
        return self._paused

    def pause_execution(self) -> None:
        if not self._active_paths:
            raise RuntimeError("No active execution to pause")
        self._paused = True
        self._step_mode = False
        self._step_boundary_indices.clear()
        self._send_zero_to_active()

    def continue_execution(self) -> None:
        if not self._active_paths:
            raise RuntimeError("No active execution to continue")
        self._paused = False
        self._step_mode = False
        self.step_completed = False

    def step_execution(self) -> None:
        if not self._active_paths or not self._paused:
            raise RuntimeError("Step requires a paused execution")
        self._step_boundary_indices = dict(self._waypoint_indices)
        self._step_mode = True
        self._paused = False
        self.step_completed = False

    def _tick_patrols(self, live_robots: dict[tuple[bool, int], LiveRobot]) -> None:
        """Drive each patrolling obstacle back and forth along its waypoints.

        The obstacle bounces at the ends of the list (reversing direction)
        rather than wrapping from the last waypoint back to the first -- so
        it always retraces the same line and never needs to "jump" across
        the field to close a loop.
        """
        for key, waypoints in self._patrol_paths.items():
            robot = live_robots.get(key)
            if robot is None or len(waypoints) <= 1:
                continue
            index = self._patrol_indices[key]
            direction = self._patrol_directions[key]
            target = waypoints[index]
            if hypot(target[0] - robot.position_mm[0], target[1] - robot.position_mm[1]) <= 120.0:
                if index + direction < 0 or index + direction >= len(waypoints):
                    direction = -direction
                    self._patrol_directions[key] = direction
                index += direction
                self._patrol_indices[key] = index
                target = waypoints[index]
            self._command_dispatcher.publish(
                waypoint_command(robot, target, max_speed_mps=self._patrol_speeds.get(key))
            )

    def execute_tick(self, live_robots: dict[tuple[bool, int], LiveRobot]) -> bool:
        """Send one control tick and return True when every path has arrived."""
        if self._patrol_paths and not (self._paused and not self._step_mode):
            self._tick_patrols(live_robots)
        if not self._active_paths:
            return True
        self.last_waypoint_transitions = ()
        if self._paused and not self._step_mode:
            return False
        all_arrived = True
        step_finished = self._step_mode
        transitions = []
        for key, path in self._active_paths.items():
            robot = live_robots.get(key)
            index = self._waypoint_indices[key]
            if robot is None:
                self._send_stop(key)
                all_arrived = False
                continue
            while index < len(path.points_mm):
                target = path.points_mm[index]
                threshold_mm = 60.0 if index == len(path.points_mm) - 1 else 120.0
                if (
                    hypot(
                        target[0] - robot.position_mm[0],
                        target[1] - robot.position_mm[1],
                    )
                    > threshold_mm
                ):
                    break
                reached_index = index
                index += 1
                transitions.append((key, reached_index))
                if self._step_mode:
                    break
            self._waypoint_indices[key] = index
            if index >= len(path.points_mm):
                self._send_stop(key)
                continue
            if self._step_mode and index > self._step_boundary_indices.get(key, index):
                self._send_stop(key)
                continue
            if self._step_mode:
                step_finished = False
            all_arrived = False
            self._command_dispatcher.publish(waypoint_command(robot, path.points_mm[index]))
        self.last_waypoint_transitions = tuple(transitions)
        if self._step_mode and step_finished:
            self._send_zero_to_active()
            self._step_mode = False
            self._paused = True
            self.step_completed = True
        return all_arrived

    def stop_execution(self) -> None:
        self.emergency_stop()

    def emergency_stop(
        self, extra_robot_keys: tuple[tuple[bool, int], ...] = ()
    ) -> tuple[str, ...]:
        """Best-effort zero commands; one failure never skips another robot."""
        errors = []
        keys = tuple(dict.fromkeys((*self._active_paths, *extra_robot_keys)))
        self._command_dispatcher.stop()
        for key in keys:
            try:
                self._send_stop(key)
            except Exception as exc:  # noqa: BLE001 - continue stopping other robots
                errors.append(f"{key}: {exc}")
        self._active_paths.clear()
        self._waypoint_indices.clear()
        self._patrol_paths.clear()
        self._patrol_indices.clear()
        self._patrol_directions.clear()
        self.active_paths = ()
        self._paused = False
        self._step_mode = False
        self._step_boundary_indices.clear()
        self.step_completed = False
        self.last_waypoint_transitions = ()
        return tuple(errors)

    def send_robot_command(self, command: RobotCommand) -> None:
        self._get_sender().send_robot_command(command)

    def stop_robot(self, is_yellow: bool, robot_id: int) -> None:
        self._send_stop((bool(is_yellow), int(robot_id)))

    def _send_zero_to_active(self) -> None:
        for key in self._active_paths:
            self._send_stop(key)

    def _send_stop(self, key: tuple[bool, int]) -> None:
        is_yellow, robot_id = key
        command = RobotCommand(robot_id=robot_id, isYellow=is_yellow)
        if self._command_dispatcher.running:
            self._command_dispatcher.publish(command)
        else:
            self._get_sender().send_robot_command(command)

    def test_grsim_connection(self) -> ConnectionProbe:
        """Verify that the configured UDP destination is routable locally.

        UDP has no handshake, so receipt must be confirmed separately through
        grSim vision.
        """
        sender = self._get_sender()
        sender.sock.connect(sender.destination)
        local_address = sender.sock.getsockname()
        return ConnectionProbe(sender.destination, (str(local_address[0]), int(local_address[1])))

    def _get_sender(self) -> grSimSender:
        """Return the cached grSim command sender, rebuilding it only when
        ``network_input.yaml`` actually changed.

        This is on the command-dispatch hot path (up to ``command_send_hz``
        per active robot -- 100/s by default), so re-reading and re-parsing
        the YAML file on every call was a real, continuous cost for no
        reason: the config only ever changes when someone edits it via the
        Configurations tab. An mtime check (a cheap stat(), not a re-parse)
        is what still lets that live edit take effect without paying full
        file-read + YAML-parse cost on every single command.
        """
        config_path = Path(__file__).resolve().parents[1] / "config" / "network_input.yaml"
        mtime = config_path.stat().st_mtime
        if self._network_config_mtime != mtime:
            config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            self._network_config_destination = (
                str(config["grsim_command_ip"]),
                int(config["grsim_command_port"]),
            )
            self._network_config_mtime = mtime
        destination = self._network_config_destination
        assert destination is not None
        if self._sender is None or self._sender.destination != destination:
            if self._sender is not None:
                self._sender.close()
            self._sender = grSimSender(ip=destination[0], port=destination[1])
        return self._sender
